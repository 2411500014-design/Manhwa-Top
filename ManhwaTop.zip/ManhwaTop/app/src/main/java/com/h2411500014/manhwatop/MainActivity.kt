package com.h2411500014.manhwatop

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val registerButton = findViewById<Button>(R.id.registerButton)
        val loginLink = findViewById<TextView>(R.id.loginLink)
        val emailEditText = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.emailEditText)
        val passwordEditText = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.passwordEditText)
        val confirmPasswordEditText = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.confirmPasswordEditText)

        registerButton.setOnClickListener {
            val email = emailEditText?.text?.toString() ?: ""
            val password = passwordEditText?.text?.toString() ?: ""
            val confirmPassword = confirmPasswordEditText?.text?.toString() ?: ""

            if (email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
                Toast.makeText(this, "Semua field harus diisi", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (password != confirmPassword) {
                Toast.makeText(this, "Password tidak cocok", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Navigate to Beranda after successful registration
            val intent = Intent(this, BerandaActivity::class.java)
            startActivity(intent)
            finish()
        }

        loginLink.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}