package com.h2411500014.manhwatop

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class BerandaActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var manhwaAdapter: ManhwaAdapter
    private lateinit var searchEditText: TextInputEditText
    private lateinit var genreButton: MaterialButton
    private lateinit var progressBar: ProgressBar

    private val originalManhwaList = ArrayList<HashMap<String, String>>()
    private val filteredManhwaList = ArrayList<HashMap<String, String>>()
    private var selectedGenre: String? = null

    private val BASE_URL = "http:// 192.168.1.78/manhwa_top/api/manhwa.php"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_beranda)

        recyclerView = findViewById(R.id.recyclerViewManhwa)
        searchEditText = findViewById(R.id.searchEditText)
        genreButton = findViewById(R.id.genreButton)
        progressBar = findViewById(R.id.progressBar)

        setupRecyclerView()
        setupSearchListener()
        setupGenreButton()
        loadData()
    }

    private fun setupRecyclerView() {
        manhwaAdapter = ManhwaAdapter(filteredManhwaList)
        recyclerView.apply {
            layoutManager = LinearLayoutManager(this@BerandaActivity)
            adapter = manhwaAdapter
            setHasFixedSize(true)
        }
    }

    private fun setupSearchListener() {
        searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                filterData(s?.toString() ?: "")
            }
        })
    }

    private fun setupGenreButton() {
        genreButton.setOnClickListener {
            showGenreDialog()
        }
    }

    private fun loadData() {
        progressBar.visibility = View.VISIBLE

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                // Fetch list manhwa
                val jsonResponse = makeNetworkRequest(URL(BASE_URL))
                val manhwaList = parseJson(jsonResponse)

                // Fetch detail untuk setiap manhwa untuk mendapatkan genre
                val manhwaListWithGenre = manhwaList.map { manhwa ->
                    val id = manhwa["id_manhwa"] ?: ""
                    if (id.isNotEmpty()) {
                        try {
                            val detailUrl = "$BASE_URL?id=$id"
                            val detailResponse = makeNetworkRequest(URL(detailUrl))
                            val detailJson = JSONObject(detailResponse)
                            
                            if (detailJson.has("status") && detailJson.getString("status") == "success") {
                                val detailData = detailJson.getJSONObject("data")
                                
                                // Update genre dari detail
                                if (detailData.has("genre")) {
                                    val genreValue = detailData.get("genre")
                                    if (genreValue is JSONArray) {
                                        val genreList = ArrayList<String>()
                                        for (j in 0 until genreValue.length()) {
                                            genreList.add(genreValue.getString(j))
                                        }
                                        manhwa["genre"] = genreList.joinToString(", ")
                                    } else {
                                        manhwa["genre"] = genreValue.toString()
                                    }
                                    Log.d("BerandaActivity", "Genre untuk ${manhwa["nama_manhwa"]}: ${manhwa["genre"]}")
                                }
                                
                                // Update cover_manhwa dari detail (biasanya lebih lengkap)
                                if (detailData.has("cover_manhwa")) {
                                    val coverUrl = detailData.optString("cover_manhwa", "")
                                    if (coverUrl.isNotEmpty() && coverUrl != "null") {
                                        manhwa["cover_manhwa"] = coverUrl
                                        Log.d("BerandaActivity", "Cover URL untuk ${manhwa["nama_manhwa"]}: $coverUrl")
                                    }
                                }
                            }
                        } catch (e: Exception) {
                            Log.e("BerandaActivity", "Error fetching detail for id $id", e)
                            // Jika gagal, tetap gunakan manhwa tanpa genre
                        }
                    }
                    manhwa
                }

                withContext(Dispatchers.Main) {
                    originalManhwaList.clear()
                    originalManhwaList.addAll(manhwaListWithGenre)
                    filterData("")
                }
            } catch (e: Exception) {
                Log.e("BerandaActivity", "Error loading data", e)
                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        this@BerandaActivity,
                        "Gagal memuat data: ${e.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            } finally {
                withContext(Dispatchers.Main) {
                    progressBar.visibility = View.GONE
                }
            }
        }
    }

    private fun makeNetworkRequest(url: URL): String {
        val connection = url.openConnection() as HttpURLConnection

        try {
            connection.requestMethod = "GET"
            connection.connectTimeout = 15000
            connection.readTimeout = 10000

            return BufferedReader(InputStreamReader(connection.inputStream)).use { reader ->
                val stringBuilder = StringBuilder()
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    stringBuilder.append(line)
                }
                stringBuilder.toString()
            }
        } finally {
            connection.disconnect()
        }
    }

    private fun parseJson(jsonString: String): List<HashMap<String, String>> {
        val manhwaList = ArrayList<HashMap<String, String>>()
        val jsonObject = JSONObject(jsonString)
        
        // Handle response dengan status
        if (jsonObject.has("status") && jsonObject.getString("status") == "success") {
            val dataArray = jsonObject.getJSONArray("data")

            for (i in 0 until dataArray.length()) {
                val manhwaObject = dataArray.getJSONObject(i)
                val manhwaMap = HashMap<String, String>()
                
                manhwaMap["id_manhwa"] = manhwaObject.optString("id_manhwa", "")
                manhwaMap["nama_manhwa"] = manhwaObject.optString("nama_manhwa", "")
                manhwaMap["penulis"] = manhwaObject.optString("penulis", "")
                manhwaMap["penerbit"] = manhwaObject.optString("penerbit", "")
                manhwaMap["tahun_terbit"] = manhwaObject.optString("tahun_terbit", "")
                
                // Handle cover_manhwa - bisa null atau string
                val coverManhwa = manhwaObject.optString("cover_manhwa", "")
                manhwaMap["cover_manhwa"] = if (coverManhwa == "null" || coverManhwa.isEmpty()) {
                    ""
                } else {
                    coverManhwa
                }
                
                // Log untuk debug
                Log.d("BerandaActivity", "Cover URL: ${manhwaMap["cover_manhwa"]}")
                
                // Handle genre - di list biasanya tidak ada, akan di-fetch dari detail
                // Tapi tetap cek jika ada
                if (manhwaObject.has("genre")) {
                    val genreValue = manhwaObject.get("genre")
                    if (genreValue is JSONArray) {
                        val genreList = ArrayList<String>()
                        for (j in 0 until genreValue.length()) {
                            genreList.add(genreValue.getString(j))
                        }
                        manhwaMap["genre"] = genreList.joinToString(", ")
                    } else if (genreValue.toString() != "null") {
                        manhwaMap["genre"] = genreValue.toString()
                    } else {
                        manhwaMap["genre"] = ""
                    }
                } else {
                    manhwaMap["genre"] = ""
                }
                
                Log.d("BerandaActivity", "Manhwa: ${manhwaMap["nama_manhwa"]}, Genre: ${manhwaMap["genre"]}")
                
                manhwaList.add(manhwaMap)
            }
        }

        return manhwaList
    }

    private fun filterData(keyword: String) {
        filteredManhwaList.clear()

        if (keyword.isEmpty() && selectedGenre == null) {
            filteredManhwaList.addAll(originalManhwaList)
        } else {
            val filteredResults = originalManhwaList.filter { manhwa ->
                val nama = manhwa["nama_manhwa"] ?: ""
                val penulis = manhwa["penulis"] ?: ""
                val genre = manhwa["genre"] ?: ""
                
                val matchesSearch = keyword.isEmpty() || 
                    nama.contains(keyword, ignoreCase = true) || 
                    penulis.contains(keyword, ignoreCase = true) ||
                    genre.contains(keyword, ignoreCase = true)
                
                val matchesGenre = selectedGenre == null || 
                    genre.contains(selectedGenre!!, ignoreCase = true)
                
                matchesSearch && matchesGenre
            }
            filteredManhwaList.addAll(filteredResults)
        }

        manhwaAdapter.notifyDataSetChanged()
    }

    private fun getAllGenres(): List<String> {
        val genres = mutableSetOf<String>()
        originalManhwaList.forEach { manhwa ->
            val genreString = manhwa["genre"] ?: ""
            if (genreString.isNotEmpty()) {
                genreString.split(",").forEach { genre ->
                    genres.add(genre.trim())
                }
            }
        }
        return genres.sorted()
    }

    private fun showGenreDialog() {
        val genres = getAllGenres()
        val genreArray = mutableListOf("Semua Genre")
        genreArray.addAll(genres)

        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,
            genreArray
        )

        val builder = AlertDialog.Builder(this)
        builder.setTitle("Pilih Genre")
        builder.setAdapter(adapter) { dialog, which ->
            if (which == 0) {
                selectedGenre = null
                genreButton.text = "Genre"
            } else {
                selectedGenre = genres[which - 1]
                genreButton.text = selectedGenre
            }
            filterData(searchEditText.text?.toString() ?: "")
            dialog.dismiss()
        }
        builder.setNegativeButton("Batal", null)
        builder.show()
    }
}
