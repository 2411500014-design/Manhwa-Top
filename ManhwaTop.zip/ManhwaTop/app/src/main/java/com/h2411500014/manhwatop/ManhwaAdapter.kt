package com.h2411500014.manhwatop

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load

class ManhwaAdapter(private var manhwaList: List<HashMap<String, String>>) :
    RecyclerView.Adapter<ManhwaAdapter.ManhwaViewHolder>() {

    class ManhwaViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val coverImageView: ImageView = itemView.findViewById(R.id.coverManhwa)
        val namaTextView: TextView = itemView.findViewById(R.id.namaManhwa)
        val genreTextView: TextView = itemView.findViewById(R.id.genreManhwa)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ManhwaViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_manhwa, parent, false)
        return ManhwaViewHolder(view)
    }

    override fun onBindViewHolder(holder: ManhwaViewHolder, position: Int) {
        val manhwa = manhwaList[position]
        
        // Load image from URL using Coil
        var coverUrl = manhwa["cover_manhwa"] ?: ""
        
        // Log untuk debug
        Log.d("ManhwaAdapter", "Position: $position, Nama: ${manhwa["nama_manhwa"]}, Original cover URL: $coverUrl")
        
        // Jika URL relatif atau tidak lengkap, tambahkan base URL
        if (coverUrl.isNotEmpty() && coverUrl != "null" && coverUrl != "NULL") {
            // Jika URL tidak dimulai dengan http, tambahkan base URL
            if (!coverUrl.startsWith("http://") && !coverUrl.startsWith("https://")) {
                // Jika URL dimulai dengan /, hapus slash pertama
                if (coverUrl.startsWith("/")) {
                    coverUrl = coverUrl.substring(1)
                }
                // Tambahkan base URL
                coverUrl = "http://10.208.186.63/manhwa_top/$coverUrl"
            }
            
            Log.d("ManhwaAdapter", "Final cover URL: $coverUrl")
            
            try {
                // Load gambar dengan Coil
                holder.coverImageView.load(coverUrl) {
                    placeholder(android.R.drawable.ic_menu_gallery)
                    error(android.R.drawable.ic_menu_gallery)
                    crossfade(true)
                    allowHardware(false)
                    listener(
                        onStart = { Log.d("ManhwaAdapter", "Loading image: $coverUrl") },
                        onSuccess = { _, _ -> Log.d("ManhwaAdapter", "Image loaded successfully: $coverUrl") },
                        onError = { _, result -> Log.e("ManhwaAdapter", "Error loading image: $coverUrl", result.throwable) }
                    )
                }
            } catch (e: Exception) {
                Log.e("ManhwaAdapter", "Exception loading image: $coverUrl", e)
                holder.coverImageView.setImageResource(android.R.drawable.ic_menu_gallery)
            }
        } else {
            Log.d("ManhwaAdapter", "Cover URL kosong atau null, menggunakan placeholder")
            holder.coverImageView.setImageResource(android.R.drawable.ic_menu_gallery)
        }
        
        holder.namaTextView.text = manhwa["nama_manhwa"] ?: "Nama tidak tersedia"
        val genreText = manhwa["genre"] ?: "Genre tidak tersedia"
        holder.genreTextView.text = genreText
    }

    override fun getItemCount(): Int = manhwaList.size
}
